import boto3
import json
import os
from datetime import datetime

def lambda_handler(event, context):
    tableName = os.environ['Table']
    key = event['Records'][0]['s3']['object']['key']
    user = key.split("/")[0]
    print ("key:", key)
    print ("user:", user)
    
    client = boto3.resource('dynamodb')
    table = client.Table(tableName)
    
    now = datetime.now()
    date = now.strftime("%d/%m/%Y")
    
    try:
        response = table.put_item(Item= {'object': user, 'date': date})
        return response
    except Exception as e:
        print(e)
        raise e
