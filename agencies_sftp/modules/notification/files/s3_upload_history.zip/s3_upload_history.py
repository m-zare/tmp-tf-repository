import boto3
import json
import os
from datetime import datetime

transferClient = boto3.client('transfer')
dynamodbClient = boto3.resource('dynamodb')

def lambda_handler(event, context):
    tableName = os.environ['Table']
    key = event['Records'][0]['s3']['object']['key']
    user = key.split("/")[0]
    print ("key:", key)
    print ("user:", user)
    
    table = dynamodbClient.Table(tableName)
    
    now = datetime.now()
    date = now.strftime("%d/%m/%Y")
    
    try:
        response = table.put_item(Item= {'object': user + "_" + date})
        return response
    except Exception as e:
        print(e)
        raise e
