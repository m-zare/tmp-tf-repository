import json
import urllib.parse
import boto3
import os
from datetime import datetime, timedelta
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

transferClient = boto3.client('transfer')
dynamodbClient = boto3.resource('dynamodb')

def getServerID(arn):
    servers = transferClient.list_servers()
    for server in servers["Servers"]:
        if server["Arn"] == arn:
            return server["ServerId"]
    return ""

def getServerUsers(serverID):
    users = transferClient.list_users(ServerId=serverID)
    usersOnServer = []
    for user in users["Users"]:
        usersOnServer.append(user["UserName"])
    return usersOnServer

def getActiveUsers(table):
    date = (datetime.now() - timedelta(1)).strftime("%d/%m/%Y")       
    rows = table.scan()
    
    users = []
    for row in rows['Items']:
        if date in row['object']:
            users.append(row['object'].split("_")[0])
    return users

def deleteItem(table, user):
    date = (datetime.now() - timedelta(1)).strftime("%d/%m/%Y")       

    try:
        response = table.delete_item(
            Key={
                'object': user + "_" + date
            },
        )
        print(user, 'deleted!')
        return response
    except ClientError as e:
        if e.response['Error']['Code'] == "ConditionalCheckFailedException":
            print(e.response['Error']['Message'])
        else:
            raise

def send_email(user):
    SENDER = "{} <{}>".format(os.environ['SenderName'], os.environ['SenderEmail'])
    RECIPIENT = os.environ['RecipientEmail']
    AWS_REGION = os.environ['Region']
    SUBJECT = "Upload Missing for " + user

    date = (datetime.now() - timedelta(1)).strftime("%d/%m/%Y")       
    BODY_TEXT = ("Amazon SES\r\n {} has not uploaded any file on {}".format(user, date))
    BODY_HTML = """<html>
    <head></head>
    <body>
        <h1>Amazon SES</h1>
        <p><strong>{}</strong> has not uploaded any file on <strong>{}</strong></p>
    </body>
    </html>
                """.format(user, date)         
    CHARSET = "UTF-8"
    client = boto3.client('ses',region_name=AWS_REGION)
    try:
        response = client.send_email(
            Destination={
                'ToAddresses': [
                    RECIPIENT,
                ],
            },
            Message={
                'Body': {
                    'Html': {
                        'Charset': CHARSET,
                        'Data': BODY_HTML,
                    },
                    'Text': {
                        'Charset': CHARSET,
                        'Data': BODY_TEXT,
                    },
                },
                'Subject': {
                    'Charset': CHARSET,
                    'Data': SUBJECT,
                },
            },
            Source=SENDER,
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(response['MessageId'])

def lambda_handler(event, context):
    serverID = os.environ['ServerID']
    table = dynamodbClient.Table(os.environ['Table'])

    usersOnServer = getServerUsers(serverID)
    if len(usersOnServer) == 0:
        raise Exception("No user found on the server!")
    print("usersOnServer:",usersOnServer)
    
    activeUsers = getActiveUsers(table)
    print("activeUsers:",activeUsers)
    
    set_difference = set(usersOnServer) - set(activeUsers)
    if len(set_difference) > 0:
        for u in set_difference:
            print("notification fire for",u)
            send_email(u)
    
    for user in activeUsers:
        deleteItem(table, user)
