import json
import urllib.parse
import boto3
import os
from datetime import datetime, timedelta
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

transferClient = boto3.client('transfer')
dynamodbClient = boto3.resource('dynamodb')

def getServerID(arn):
    servers = transferClient.list_servers()
    for server in servers["Servers"]:
        if server["Arn"] == arn:
            return server["ServerId"]
    return ""

def getServerUsers(serverID):
    users = transferClient.list_users(ServerId=serverID)
    usersOnServer = []
    for user in users["Users"]:
        usersOnServer.append(user["UserName"])
    return usersOnServer

def getActiveUsers(tableName):
    table = dynamodbClient.Table(tableName)
    rows = table.scan()

    yesterday = datetime.now() - timedelta(1)
    date = yesterday.strftime("%d/%m/%Y")
    
    users = []
    for row in rows['Items']:
        if date in row['object']:
            users.append(row['object'].split("_")[0])
    return users

def deleteItem(tableName, user):
    table = dynamodbClient.Table(tableName)
    yesterday = datetime.now() - timedelta(1)
    date = yesterday.strftime("%d/%m/%Y")

    try:
        response = table.delete_item(
            Key={
                'object': user + "_" + date
            },
        )
        print(user, 'deleted!')
        return response
    except ClientError as e:
        if e.response['Error']['Code'] == "ConditionalCheckFailedException":
            print(e.response['Error']['Message'])
        else:
            raise

def lambda_handler(event, context):
    serverARN = os.environ['ServerARN']
    serverID = getServerID(serverARN)
    if serverID == "":
        raise Exception("serverID is not known!")
    
    usersOnServer = getServerUsers(serverID)
    if len(usersOnServer) == 0:
        raise Exception("No user found on the server!")
    print("usersOnServer:",usersOnServer)
    
    table = os.environ['Table']
    activeUsers = getActiveUsers(table)
    print("activeUsers:",activeUsers)
    
    set_difference = set(usersOnServer) - set(activeUsers)
    if len(set_difference) > 0:
        for u in set_difference:
            print("notification fire for",u)
            send_email(u)
    
    for user in activeUsers:
        deleteItem(table, user)

def send_email(user):
  # Replace sender@example.com with your "From" address.
  # This address must be verified with Amazon SES.
  SENDER = "Sender Name <mostafazare@gmail.com>"

  # Replace recipient@example.com with a "To" address. If your account 
  # is still in the sandbox, this address must be verified.
  RECIPIENT = "mostafazare@gmail.com"

  # Specify a configuration set. If you do not want to use a configuration
  # set, comment the following variable, and the 
  # ConfigurationSetName=CONFIGURATION_SET argument below.
#   CONFIGURATION_SET = "ConfigSet"

  # If necessary, replace us-west-2 with the AWS Region you're using for Amazon SES.
  AWS_REGION = "eu-west-1"

  # The subject line for the email.
  SUBJECT = "Amazon SES Test (SDK for Python)"

  # The email body for recipients with non-HTML email clients.
  BODY_TEXT = ("Amazon SES Test (Python)\r\n"
              "This email was sent with Amazon SES using the "
              "AWS SDK for Python (Boto)."+ user
              )
              
  # The HTML body of the email.
  BODY_HTML = """<html>
  <head></head>
  <body>
    <h1>Amazon SES Test (SDK for Python)</h1>
    <p>This email was sent with
      <a href='https://aws.amazon.com/ses/'>Amazon SES</a> using the
      <a href='https://aws.amazon.com/sdk-for-python/'>
        AWS SDK for Python (Boto)</a>.</p>
  </body>
  </html>
              """            

  # The character encoding for the email.
  CHARSET = "UTF-8"

  # Create a new SES resource and specify a region.
  client = boto3.client('ses',region_name=AWS_REGION)

  # Try to send the email.
  try:
      #Provide the contents of the email.
      response = client.send_email(
          Destination={
              'ToAddresses': [
                  RECIPIENT,
              ],
          },
          Message={
              'Body': {
                  'Html': {
                      'Charset': CHARSET,
                      'Data': BODY_HTML,
                  },
                  'Text': {
                      'Charset': CHARSET,
                      'Data': BODY_TEXT,
                  },
              },
              'Subject': {
                  'Charset': CHARSET,
                  'Data': SUBJECT,
              },
          },
          Source=SENDER,
          # If you are not using a configuration set, comment or delete the
          # following line
        #   ConfigurationSetName=CONFIGURATION_SET,
      )
  # Display an error if something goes wrong.	
  except ClientError as e:
      print(e.response['Error']['Message'])
  else:
      print("Email sent! Message ID:"),
      print(response['MessageId'])