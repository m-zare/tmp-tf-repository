import json
import urllib.parse
import boto3
import os
from datetime import datetime, timedelta
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

transferClient = boto3.client('transfer')
s3Client = boto3.client('s3')

date = (datetime.now() - timedelta(1)).strftime("%Y-%m-%d")

def getServerUsers(serverID):
    users = transferClient.list_users(ServerId=serverID)
    usersOnServer = []
    for user in users["Users"]:
        usersOnServer.append(user["UserName"])
    return usersOnServer

def sendEmail(user):
    SENDER = "{} <{}>".format(os.environ['SenderName'], os.environ['SenderEmail'])
    RECIPIENT = os.environ['RecipientEmail']
    AWS_REGION = os.environ['Region']
    SUBJECT = "Upload Missing for " + user

    BODY_TEXT = ("Amazon SES\r\n {} has not uploaded any file on {}".format(user, date))
    BODY_HTML = """<html>
    <head></head>
    <body>
        <h1>Amazon SES</h1>
        <p><strong>{}</strong> has not uploaded any file on <strong>{}</strong></p>
        <br>
        <p>This email is generated on {}.</p>
    </body>
    </html>
                """.format(user, date, datetime.now())         
    CHARSET = "UTF-8"
    client = boto3.client('ses',region_name=AWS_REGION)
    try:
        response = client.send_email(
            Destination={
                'ToAddresses': [
                    RECIPIENT,
                ],
            },
            Message={
                'Body': {
                    'Html': {
                        'Charset': CHARSET,
                        'Data': BODY_HTML,
                    },
                    'Text': {
                        'Charset': CHARSET,
                        'Data': BODY_TEXT,
                    },
                },
                'Subject': {
                    'Charset': CHARSET,
                    'Data': SUBJECT,
                },
            },
            Source=SENDER,
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(response['MessageId'])

def getActiveUsers():
    response = s3Client.list_objects_v2(Bucket='sftp-agencies')
    users = []
    for object in response["Contents"]:
        if date == object["LastModified"].strftime("%Y-%m-%d"):
            print(object["Key"].split("/")[0])
            users.append(object["Key"].split("/")[0])
    return users

def lambda_handler(event, context):
    serverID = os.environ['ServerID']
   
    usersOnServer = getServerUsers(serverID)
    if len(usersOnServer) == 0:
        raise Exception("No user found on the server!")
    print("usersOnServer:",usersOnServer)
    
    activeUsers = getActiveUsers()
    print("activeUsers:",activeUsers)
    
    set_difference = set(usersOnServer) - set(activeUsers)
    if len(set_difference) > 0:
        for u in set_difference:
            print("notification fire for",u)
            sendEmail(u)
